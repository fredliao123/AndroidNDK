// According to the StackOverflow post below, Android NDK can't compile a single source file, so a
// solution is to add an empty file...
// Yeah... Seriously... This ACTUALLY fixed my compilation error

//https://stackoverflow.com/questions/22465933/no-rule-to-make-target-when-compiling-ndk-sources-on-windows-with-gradle